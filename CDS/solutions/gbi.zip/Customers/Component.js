jQuery.sap.declare("gbi.Component");

sap.ui.core.UIComponent.extend("gbi.Component",{
	
	metadata: {
		
		routing: {
			
			config: {
				viewType: "XML",
				viewPath: "view",
				targetControl: "splitApp",
				clearTarget: false,
				transition: "slide"
			},
			
			routes: [
			        {
			            pattern : "",
			            name : "Customers",
			            view : "Master",
			            targetAggregation : "masterPages",
			            subroutes : [
			                {
    			                pattern : "Orders/{entity}",
    			                name : "Details",
    			                view : "Details",
    			                targetAggregation : "detailPages"
			                }
			            ]
			        }
			]
			
		}
		
	},
	
	init: function() {
		
		jQuery.sap.require("sap.m.routing.RouteMatchedHandler");
		jQuery.sap.require("sap.ui.core.routing.HashChanger");
		
		//call createContent
		sap.ui.core.UIComponent.prototype.init.apply(this, arguments);
		
		this._router = this.getRouter();
		
		//initlialize the router
		this._routeHandler = new sap.m.routing.RouteMatchedHandler(this._router);
		this._router.initialize();
		
	},
	
	createContent: function() {
		
		var oView = sap.ui.view({
			id: "app",
			viewName: "view.App",
			type: "JS",
			viewData: {component: this}
		});
		
		var oModel = new sap.ui.model.odata.ODataModel("http://ts2.hana.ucc.uwm.edu:8003/GBI_000/gbi/services/gbi.xsodata");
		oView.setModel(oModel,'gbi');
		
		return oView;
		
	}
	
});