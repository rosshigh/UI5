sap.ui.define([
   "sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";
	return Controller.extend("ui5.controller.Forms", {

		onInit: function() {

			this.router = sap.ui.core.UIComponent.getRouterFor(this);
			this.getView().bindElement("gbi>/Customers('1000')");

		},

		handleNavButtonPress: function() {
			this.router.navTo("Master", {
				from: "Forms"
			});
		}
	});
});