sap.ui.jsview("gbi.view.App", {

	createContent : function() {
 		
		this.setDisplayBlock(true);
		
		return new sap.m.SplitApp("splitApp",{});
	}

});