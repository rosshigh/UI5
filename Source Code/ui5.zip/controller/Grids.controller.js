sap.ui.define([
   "sap/ui/core/mvc/Controller",
   "sap/ui/model/json/JSONModel"
], function(Controller, JSONModel) {
	"use strict";
	return Controller.extend("ui5.controller.Grids", {
		onInit: function() {
			this.router = sap.ui.core.UIComponent.getRouterFor(this);
			
		    var oModel = new JSONModel("model/people.json");
            this.getView().setModel(oModel,'people');

		},

		handleNavButtonPress: function() {
			this.router.navTo("Master", {
				from: "Grids"
			});
		}

	});
});