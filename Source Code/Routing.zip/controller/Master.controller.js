sap.ui.define([
   "sap/ui/core/mvc/Controller"
], function (Controller) {
   "use strict";
   return Controller.extend("routing.controller.Master", {
       onInit: function(){
           this.router = sap.ui.core.UIComponent.getRouterFor(this);
       },
       
        go: function(oEvent){
           var entity = oEvent.getSource().getBindingContext().getPath().split("/");

        	this.router.navTo("Detail1", {
        		parameter: entity[2]
        	});
        }
   });
});