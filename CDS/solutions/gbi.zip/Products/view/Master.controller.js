sap.ui.controller("gbi.view.Master", {
    
   	onInit: function() {
		
		this.router = sap.ui.core.UIComponent.getRouterFor(this);
	},
	
	handleListItemPress: function(oItem){

	   var entity = oItem.getSource().getBindingContext("gbi").getPath().split("'");

		this.router.navTo("Products", {
			from: "Master",
			entity: entity[1]
		});
	  
	}

});