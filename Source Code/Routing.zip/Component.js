sap.ui.define([
   "sap/ui/core/UIComponent",
   "sap/ui/model/json/JSONModel"
], function(UIComponent, JSONModel) {
	"use strict";
	return UIComponent.extend("routing.Component", {
		metadata: {
			rootView: "routing.view.App",

			routing: {

				config: {
					viewType: "XML",
					viewPath: "routing.view",
					transition: "slide",
					clearTarget: true,
					targetControl: "idAppControl"
				},

                routes: [
                	{
                		pattern: "",
                		name: "Master",
                		view: "Master",
                		targetAggregation: "masterPages"
                    },
                	{
                		pattern: "Detail1/{parameter}",
                		name: "Detail1",
                		view: "Detail1",
                		targetAggregation: "detailPages"
                    },
                	{
                		pattern: "Detail2",
                		name: "Detail2",
                		view: "Detail2",
                		targetAggregation: "detailPages"
                    }
                ]
			}

		},

		init: function() {
			UIComponent.prototype.init.apply(this, arguments);

			this.getRouter().initialize();

			var oModel = new JSONModel("model/data.json");
			this.setModel(oModel);
		}
	});
});