sap.ui.define([
   "sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";
	return Controller.extend("ui5.controller.IconTab", {
		onInit: function() {
			this.router = sap.ui.core.UIComponent.getRouterFor(this);
			
// 			var oComp = sap.ui.getCore().createComponent({
//                  name: "ui5.view.components",
//                  id: "Table"
//             });
    
//             this._oTable = new sap.ui.core.ComponentContainer("TableCom", {
//                      component: oComp
//             });
//             this.getView().byId("idIconTabBar").insertContent(this._oTable);
//         oCompCont.placeAt("target1");
			
			var oComp = sap.ui.getCore().createComponent({
        		name : 'ui5.view.components'
        	});
        	oComp.setModel(this.getView().getModel('gbi'));
        	this._oTable = oComp.getTable();
        	this.getView().byId("idIconTabBar").insertContent(this._oTable);
        
//         	// update table
        // 	this._oTable.setHeaderText(null);
        // 	this._oTable.setShowSeparators("Inner");

		},

		handleNavButtonPress: function() {
			this.router.navTo("Master", {
				from: "IconTab"
			});
		},

		handleIconTabBarSelect: function(oEvent) {
			var oTable = this.byId("idProductsTable");
			var oBinding = oTable.getBinding("items");
			var sKey = oEvent.getParameter("selectedKey");
            var oFilter;
			if (sKey === "EBI") {
				oFilter = new sap.ui.model.Filter("ProductCategory", "EQ", "EBI");
				oBinding.filter([oFilter]);
			} else if (sKey === "TOU") {
				oFilter = new sap.ui.model.Filter("ProductCategory", "EQ", "TOU");
				oBinding.filter([oFilter]);
			} else if (sKey === "TRE") {
				oFilter = new sap.ui.model.Filter("ProductCategory", "EQ", "TRE");
				oBinding.filter([oFilter]);
			} else {
				oBinding.filter([]);
			}
		}

	});
});