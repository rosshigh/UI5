sap.ui.define([
   "sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";
	return Controller.extend("ui5.controller.Buttons", {
		onInit: function() {
			this.router = sap.ui.core.UIComponent.getRouterFor(this);
		},

		handleNavButtonPress: function() {
			this.router.navTo("Master", {
				from: "Buttons"
			});
		},

		onPress: function(evt) {
			jQuery.sap.require("sap.m.MessageToast");
			sap.m.MessageToast.show("Pressed: " + evt.getSource().getId());
		},

		handleOpen: function(oEvent) {
			var oButton = oEvent.getSource();

			// create action sheet only once
			if (!this._actionSheet) {
				this._actionSheet = sap.ui.xmlfragment(
					"ui5.view.ActionSheet",
					this
				);
				this.getView().addDependent(this._actionSheet);
			}
			this._actionSheet.openBy(oButton);
		},

		handlePressOpenMenu: function(oEvent) {
			var oButton = oEvent.getSource();

			if (!this._menu) {
				this._menu = sap.ui.xmlfragment(
					"ui5.view.Menu",
					this
				);
				this.getView().addDependent(this._menu);
			}

			var eDock = sap.ui.core.Popup.Dock;
			this._menu.open(this._bKeyboard, oButton, eDock.BeginTop, eDock.BeginBottom, oButton);
		},

		handleTextFieldItemPress: function(oEvent) {
			var msg = "'" + oEvent.getParameter("item").getValue() + "' entered";
			sap.m.MessageToast.show(msg);
		}

	});
});