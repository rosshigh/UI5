jQuery.sap.require("sap.ui.core.UIComponent");
jQuery.sap.declare("ui5.view.components.Component");

sap.ui.core.UIComponent.extend("ui5.view.components.Component", {

	metadata : {
	   
		publicMethods : [
			"getTable"
		],
		dependencies : {
			libs : [
				"sap.m",
				"sap.ui.layout"
			]
		},
		config : {
			sample : {
				files : [
					"TableComponent.view.xml",
					"TableComponent.controller.js"
				]
			}
		}
	},
	
	getTable : function () {
		return this._rootView.getContent()[0];
	},

	createContent : function(){
    	this._rootView = sap.ui.xmlview({ viewName : "ui5.view.components.TableComponent" });
    	return this._rootView;
    }

});

// ui5.view.components.Component.prototype.createContent = function () {
// 	this._rootView = sap.ui.xmlview({ viewName : "ui5.view.components.TableComponent" });
// 	return this._rootView;
// };