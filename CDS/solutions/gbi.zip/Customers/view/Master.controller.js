sap.ui.controller("view.Master", {
    
   	onInit: function() {
		
		this.router = sap.ui.core.UIComponent.getRouterFor(this);
	},
	
	handleListItemPress: function(evt){

	   this.showDetail(evt.getSource());
	  
	},

	showDetail : function(oItem) {

        var entity = oItem.getBindingContext("gbi").getPath().split("'");

		this.router.navTo("Details", {
			from: "Master",
			entity: entity[1]
		});
	}
});