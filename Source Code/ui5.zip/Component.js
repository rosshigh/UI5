sap.ui.define([
   "sap/ui/core/UIComponent",
   "sap/ui/model/odata/ODataModel"
], function(UIComponent, ODataModel) {
	"use strict";
	return UIComponent.extend("ui5.Component", {
		metadata: {
			rootView: "ui5.view.App",

			routing: {

				config: {
					viewType: "XML",
					viewPath: "ui5.view",
					transition: "slide",
					clearTarget: true,
					targetControl: "idAppControl"
				},

				routes: [
					{
						pattern: "",
						name: "Master",
						view: "Master",
						targetAggregation: "pages"
                    },
					{
						pattern: "Resources",
						name: "Resources",
						view: "Resources",
						targetAggregation: "pages"
                    },
					{
						pattern: "HelloWorld",
						name: "HelloWorld",
						view: "HelloWorld",
						targetAggregation: "pages"
                    },
					{
						pattern: "Weather",
						name: "Weather",
						view: "Weather",
						targetAggregation: "pages"
                    },
					{
						pattern: "Buttons",
						name: "Buttons",
						view: "Buttons",
						targetAggregation: "pages"
                    },
					{
						pattern: "Tables",
						name: "Tables",
						view: "Tables",
						targetAggregation: "pages"
                    },
					{
						pattern: "Lists",
						name: "Lists",
						view: "Lists",
						targetAggregation: "pages"
                    },
					{
						pattern: "ListDetail/{entity}",
						name: "ListDetail",
						view: "ListDetail",
						targetAggregation: "pages"
                    },
					{
						pattern: "GoogleMap",
						name: "GoogleMap",
						view: "GoogleMap",
						targetAggregation: "pages"
                    },
					{
						pattern: "Forms",
						name: "Forms",
						view: "Forms",
						targetAggregation: "pages"
                    },
					{
						pattern: "Grids",
						name: "Grids",
						view: "Grids",
						targetAggregation: "pages"
                    },
					{
						pattern: "FlexBox",
						name: "FlexBox",
						view: "FlexBox",
						targetAggregation: "pages"
                    },
					{
						pattern: "IconTab",
						name: "IconTab",
						view: "IconTab",
						targetAggregation: "pages"
                    }

                ]
			}

		},

		init: function() {
			UIComponent.prototype.init.apply(this, arguments);

			this.getRouter().initialize();

			var oModel = new ODataModel("http://db1.hana2.ucc.uwm.edu:8002/gbi-student-366/gbi/services/gbi.xsodata");
			this.setModel(oModel, 'gbi');
		}
	});
});