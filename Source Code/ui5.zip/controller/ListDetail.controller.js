sap.ui.define([
   "sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";
	return Controller.extend("ui5.controller.ListDetail", {
		onInit: function() {
			this.router = sap.ui.core.UIComponent.getRouterFor(this);
			this.router.attachRoutePatternMatched(this.onRouteMatched, this);
		},

		onRouteMatched: function(oEvent) {
			//Get the route paramters
			var oParameters = oEvent.getParameters();
			//Get a reference to this view
		

			// Make sure we're in the right place 
			if (oParameters.name !== "ListDetail") {
				return;
			}
			
			this.getView().bindElement("gbi>/" + oParameters.arguments.entity);
		},

		handleNavButtonPress: function() {
			this.router.navTo("Lists", {
				from: "ListDetail"
			});
		}

	});
});