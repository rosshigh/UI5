sap.ui.define([
   "sap/ui/core/UIComponent",
   "sap/ui/model/json/JSONModel"
], function (UIComponent, JSONModel) {
   "use strict";
   return UIComponent.extend("ui5.Component", {
            metadata : {
		rootView: "ui5.view.Hello"
	},
      init : function () {
         // call the init function of the parent
         UIComponent.prototype.init.apply(this, arguments);
         
        var oModel = new JSONModel("model/HelloModel.json");
        this.setModel(oModel);
      }
   });
});