sap.ui.define([
   "sap/ui/core/UIComponent",
   "sap/ui/model/odata/ODataModel"
], function(UIComponent, ODataModel) {
	"use strict";
	return UIComponent.extend("gbi.Component", {
		metadata: {
			rootView: "gbi.view.App",

			routing: {

				config: {
					viewType: "XML",
					viewPath: "gbi.view",
					targetControl: "splitApp",
					clearTarget: true,
					transition: "slide"
				},

				routes: [
					{
						pattern: "",
						name: "ProductCategories",
						view: "Master",
						targetAggregation: "masterPages"
			        },
					{
						pattern: "ProductCategory/{entity}",
						name: "Products",
						view: "Products",
						targetAggregation: "masterPages"
			        },
					{
						pattern: "Products/{entity}",
						name: "Detail",
						view: "Detail",
						targetAggregation: "detailPages"
	                }

			]

			}

		},

		init: function() {
			UIComponent.prototype.init.apply(this, arguments);

			this.getRouter().initialize();

			var oModel = new ODataModel("http://db1.hana2.ucc.uwm.edu:8002/gbi-student-366/gbi/services/gbi.xsodata");
			this.setModel(oModel, 'gbi');
		}

	});

});