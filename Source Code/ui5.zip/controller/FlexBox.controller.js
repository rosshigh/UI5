sap.ui.define([
   "sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";
	return Controller.extend("ui5.controller.FlexBox", {
		onInit: function() {
			this.router = sap.ui.core.UIComponent.getRouterFor(this);
		},

		handleNavButtonPress: function() {
			this.router.navTo("Master", {
				from: "Grids"
			});
		}

	});
});