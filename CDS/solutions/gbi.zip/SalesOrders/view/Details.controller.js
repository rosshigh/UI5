sap.ui.controller("view.Details", {
    onInit: function() {
		
		this.router = sap.ui.core.UIComponent.getRouterFor(this);
		this.router.attachRoutePatternMatched(this.onRouteMatched, this);
	
	},

	onRouteMatched : function(oEvent) {	
		var oParameters = oEvent.getParameters();

		var oView = this.getView();

		// When navigating in the Detail page, update the binding context 
		if (oParameters.name !== "Details") { 
			return;
		}

		var sEntityPath = "/SalesOrders('" + oParameters.arguments.entity + "')";
	    var oModel = oView.getModel('gbi');
		var context = new sap.ui.model.Context(oModel , sEntityPath);
		
		oView.setBindingContext(context,'gbi');

	}
	
});