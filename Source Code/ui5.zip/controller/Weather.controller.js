sap.ui.define([
   "sap/ui/core/mvc/Controller",
   "sap/ui/model/json/JSONModel"
], function(Controller,JSONModel) {
	"use strict";
	return Controller.extend("ui5.controller.Weather", {

    	onInit: function () {  
    	    this.router = sap.ui.core.UIComponent.getRouterFor(this);
    	    
       	    this.cModel = new JSONModel();
    		this.cModel.loadData("http://api.openweathermap.org/data/2.5/weather",{"q":"Sydney","APPID":"0f85bb931f8faad7e35b6f685aa4e931"})
    		this.getView().setModel(this.cModel, "weather");
    		
    		this.fModel = new JSONModel();
    		this.fModel.loadData("http://api.openweathermap.org/data/2.5/forecast/daily",{"q":"Sydney","units":"metric","cnt":"5","APPID":"0f85bb931f8faad7e35b6f685aa4e931"});
    		this.getView().setModel(this.fModel, "forecast");
        },  
        
    	handleNavButtonPress: function(){
          	this.router.navTo("Master", {
    			from: "IconTab"
    		});
       },
    	
    	actSearch: function(){
    		 var address = this.getView().byId("inpSearch").getValue();  
            this.cModel.loadData("http://api.openweathermap.org/data/2.5/weather",{"q": address,"APPID":"0f85bb931f8faad7e35b6f685aa4e931"});
            this.fModel.loadData("http://api.openweathermap.org/data/2.5/forecast/daily",{"q": address ,"units":"metric","cnt":"5","APPID":"0f85bb931f8faad7e35b6f685aa4e931"});
    	},
    	
    	handleRefreshPressed: function(){
    		 var address = this.getView().byId("inpSearch").getValue();
    		 if(!address) address = this.cModel.getData().name;
    		 this.cModel.loadData("http://api.openweathermap.org/data/2.5/weather",{"q": address,"APPID":"0f85bb931f8faad7e35b6f685aa4e931"});
             this.fModel.loadData("http://api.openweathermap.org/data/2.5/forecast/daily",{"q": address ,"units":"metric","cnt":"5","APPID":"0f85bb931f8faad7e35b6f685aa4e931"});
    	},
    	
		date: function(date){
    		return new Date(date*1000).toLocaleDateString();
    	},

    	celsius: function(temp){
    		temp = parseFloat(temp);
    		var degreesCelsius = Math.round(temp - 273.15);
    		return degreesCelsius + "\u00b0";
    	},
    	
    	degrees: function(temp){
    		return temp + "\u00b0";
        },
        
        windDirection: function(direction){
    		return Math.round(direction) + "\u00b0";
        },
        	
        windSpeed: function(speed){
    		return speed + " kph";
        },
        
        icon: function(icon){
        	return "http://openweathermap.org/img/w/" + icon + ".png";
        }




	});
});