sap.ui.define([
   "sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";
	return Controller.extend("routing.controller.Detail1", {
		onInit: function() {

			this.router = sap.ui.core.UIComponent.getRouterFor(this);
			this.router.attachRoutePatternMatched(this.onRouteMatched, this);

		},

		onRouteMatched: function(oEvent) {
			var oParameters = oEvent.getParameters();

			if (oParameters.name !== "Detail1") {
				return;
			}
			
			this.getView().bindElement("/collection/" + oParameters.arguments.parameter);

		},
		
		Back: function(){
		    this.router.navTo('Master');
		},
		
		go: function(){
		    this.router.navTo('Detail2');
		}

	});
});