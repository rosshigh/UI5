sap.ui.define([
   "sap/ui/core/mvc/Controller",
   "sap/ui/model/json/JSONModel"
], function(Controller, JSONModel) {
	"use strict";
	return Controller.extend("ui5.controller.Master", {
		onInit: function() {
			this.router = sap.ui.core.UIComponent.getRouterFor(this);

			var oModel = new JSONModel("model/views.json");
			this.getView().setModel(oModel, "views");
		},

		handleTilePress: function(evt) {
			var oView = evt.getSource().getInfo();

			this.router.navTo(oView, {
				from: "Master"
			});
		},

		handleOpen: function(oEvent) {
			var oButton = oEvent.getSource();

			// create action sheet only once
			if (!this._actionSheet) {
				this._actionSheet = sap.ui.xmlfragment(
					"ui5.view.ActionSheet2",
					this
				);
				this.getView().addDependent(this._actionSheet);
			}
			this._actionSheet.openBy(oButton);
		},

		onPress: function(evt) {
			var id = evt.getSource().getId();
			switch (id) {
				case "idCases":
					$("#__xmlview1--caseTiles").fadeIn();
					$("#__xmlview1--exerciseTiles").fadeOut();
					break;
				case "idExercises":
					$("#__xmlview1--caseTiles").fadeOut();
					$("#__xmlview1--exerciseTiles").fadeIn();
					break;
				case "idBoth":
					$("#__xmlview1--caseTiles").fadeIn();
					$("#__xmlview1--exerciseTiles").fadeIn();
					break;
			}
		}

	});
});